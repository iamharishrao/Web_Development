var colors=randomColors(6);
var goal=goalColor();
var displayOnH1=document.getElementById("goal");
var squares=document.querySelectorAll(".square");
var messageDisplay=document.querySelector("#message");
var h1=document.querySelector("h1");
var newcolors=document.querySelector("#newcolors");
var easygame=document.querySelector("#easygame");
var toughgame=document.querySelector("#toughgame");
displayOnH1.textContent=goal;
var numOfSquares=6;
var colors=randomColors(numOfSquares);

easygame.addEventListener("click",function()
							{
								easygame.classList.add("selected");
								toughgame.classList.remove("selected");
								//generate new colors
								numOfSquares=3
								colors=randomColors(numOfSquares);
								goal=goalColor();
								displayOnH1.textContent=goal;
								for(var i=0;i<squares.length;i++)
								{
									if(colors[i])
										{squares[i].style.background=colors[i];
										}
									else
									{squares[i].style.display="none";

									}
								}

							});

toughgame.addEventListener("click",function()
							{
								toughgame.classList.add("selected");
								easygame.classList.remove("selected");
								numOfSquares=6;
								goal=goalColor();
								colors=randomColors(numOfSquares);
								for(var i=0;i<squares.length;i++)
								{
									squares[i].style.background=colors[i];
									squares[i].style.display="block";

								}
							});


newcolors.addEventListener("click",function()
								{
									//generate all new colors
									colors=randomColors(numOfSquares);
									//pick random color
									goal=goalColor();
									displayOnH1.textContent=goal;
									//fill square with these colors
									for(var i=0;i<squares.length;i++)
 										{squares[i].style.backgroundColor=colors[i];

 										}
 										h1.style.backgroundColor="steelblue";
 										
								});


 for(var i=0;i<squares.length;i++)

 	{squares[i].style.backgroundColor=colors[i];
		
 			squares[i].addEventListener("click",function()
 							{var clicked=this.style.backgroundColor;
 								if(clicked===goal)
 									{messageDisplay.textContent="Correct!";
 									 changeColors(clicked);
 									 h1.style.backgroundColor=clicked;
 									 newcolors.textContent="Play Again?";
									}


								else
 									{
 									this.style.background="#232323";
 									messageDisplay.textContent="Try Again";
 									}

 							});
 	}


function changeColors(color)
	{for(var i=0;i<squares.length;i++)
	 {squares[i].style.backgroundColor=color;

	 }
	}

function goalColor()
	{
		var random=Math.floor(Math.random()*colors.length);
		return colors[random];
	}

function randomColors(num)
	{var arr=[];
    	for(var i=0;i<num;i++)
    		{arr.push(generateColor());

	}
	 return arr;
    }
    

 function generateColor()
 {
 	var r=Math.floor(Math.random()*256);
    var g=Math.floor(Math.random()*256);
    var b=Math.floor(Math.random()*256);
    return "rgb(" + r + "," +" "+ g + "," +" " +b + ")";
     		 
 }






