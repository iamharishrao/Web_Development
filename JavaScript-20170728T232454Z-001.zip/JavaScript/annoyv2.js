var response=prompt("Are we there yet?");

while(response.indexOf("yes")&&response.indexOf("yeah"))
	{var response=prompt("Are we there yet?");

}

alert("we made it");
