var colors=["red","green","blue"];
colors.forEach(function(element)
	            {
	            	console.log(element);
	            }
	          );