function printReverse(arr)
 {
 	for(var i=arr.length-2;i>=0:i--)
 		{console.log(arr[i];)
 		}
 }

 printReverse([5,4,3,2]);