var response=prompt("Are we there yet?");

while(response!=="yes"&&response!=="yeah")
	{var response=prompt("Are we there yet?");

}

alert("we made it");

