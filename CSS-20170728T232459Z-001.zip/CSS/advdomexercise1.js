var bod=document.querySelector("body");
var isPurple=false; 
document.querySelector("button").addEventListener("click",function()
 {
  	if(isPurple==false)      
  		{bod.style.background="purple";
 		 isPurple=true; 
  		}
       
  	else
		{bod.style.background="white";
		 isPurple=false;
	    }

    }
);