var what=prompt("What up, mate ?")
alert("Hello from the JS file,"+ what);
console.log("Same here dude!"+what);