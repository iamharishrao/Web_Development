var age=prompt("Your age please");
var ly=Math.floor(age/4);
console.log("You've been alive for approximately"+" "+((age*365)+ly)+" "+"days!");