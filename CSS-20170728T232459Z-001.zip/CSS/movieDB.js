var movies=[{title:"Darpan Chaaya",rating:4.5,hasWatched:"true"},
             {title:"Darpan Chaaya 2",rating:3.5,hasWatched:"false"},
              {title:"Darpan Chaaya 3",rating:5.0,hasWatched:"true"},
                {title:"Darpan Chaaya 4",rating:2.0,hasWatched:"false"}
            ];

for(var i=0;i<movies.length-1;i++)
	{if(movies[i].hasWatched==="true")
        {console.log("You have seen"+movies[i].title+"-"+movies[i].rating);
        }

     else if(movies[i].hasWatched==="false")
     	 {console.log("u have not watched"+movies[i].title+"-"+movies[i].rating)
         }
    }
