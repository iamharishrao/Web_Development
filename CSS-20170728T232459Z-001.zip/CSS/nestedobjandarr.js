var posts=[{name:"Harish",comments:["let's do this!","let's go skydiving!"]},
            {name:"Girish",comments:["maybe later","let's go parasailing!"]},
             {name:"Dad",comments:["Yeah Sure!","Paise toh pedh pe ughte hain!!"]},
          ];