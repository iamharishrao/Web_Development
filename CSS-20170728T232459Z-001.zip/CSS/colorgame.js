var colors=randomColors(6);
var goal=goalColor();
var displayOnH1=document.getElementById("goal");
var squares=document.querySelectorAll(".square");
var messageDisplay=document.querySelector("#message");
var h1=document.querySelector("h1");
displayOnH1.textContent=goal;

 for(var i=0;i<squares.length;i++)
 	{squares[i].style.backgroundColor=colors[i];
		
 			squares[i].addEventListener("click",function()
 							{var clicked=this.style.backgroundColor;
 								if(clicked===goal)
 									{messageDisplay.textContent="Correct!";
 									 changeColors(clicked);
 									 h1.style.backgroundColor=clicked;
									}

								else
 									{
 									this.style.background="#232323";
 									messageDisplay.textContent="Try Again";
 									}

 							});
 	}


function changeColors(color)
	{for(var i=0;i<squares.length;i++)
	 {squares[i].style.backgroundColor=color;

	 }
	}

function goalColor()
	{
		var random=Math.floor(Math.random()*colors.length);
		return colors[random];
	}

function randomColors(num)
	{var arr=[];
    	for(var i=0;i<num;i++)
    		{arr.push(generateColor());

	}
	 return arr;
    }
    

 function generateColor()
 {
 	var r=Math.floor(Math.random()*256);
    var g=Math.floor(Math.random()*256);
    var b=Math.floor(Math.random()*256);
    return "rgb(" + r + "," +" "+ g + "," +" " +b + ")";
     		 
 }



