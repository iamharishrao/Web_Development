var inp=prompt("What would you like to do ?");
var arr=[];
while(inp!=="quit")
{
 	if(inp==="new")
 	{var todo=prompt("Enter activity");
 		arr.push(todo);
    }
      inp=prompt("What would you like to do ?");

 	else if(inp==="list")
    {console.log(arr);

    }

}

alert("You quit!");

