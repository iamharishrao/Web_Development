var body=document.querySelector("body");
document.querySelector("button").addEventListener("click",function()
{body.classList.toggle("purp");

});