var num=7;
var guess=Number (prompt("Guess a number"));
if(guess===num)
	{alert("Awesome, you got it right!");
}
else if(guess<=num)
	{	alert("Too low!");
}
else
	{	alert("Too high!");
}