var firstName=prompt("Hey there! What's your first name ?");
var lastName=prompt("What's your last name ?");
var age=prompt("May I know your age, please?");
console.log("Here's what I know about you!");
console.log("Your full name is"+firstName+""+lastName);
console.log("Your age is"+" "+age);