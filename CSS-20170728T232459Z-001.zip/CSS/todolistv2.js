var arr=[];
inp=prompt("What would you like to do ?");

while(inp!=="quit")
{
 	if(inp==="new")
 	{addToList();
    }
      

 	else if(inp==="list")
    {
       printList();
    }

    else if(inp==="delete")
    {
    	deleteFromList();
    }
    inp=prompt("What would you like to do ?");


}

console.log("You quit!");





function addToList()
{ var newTodo=prompt("Enter activity");
 		arr.push(newTodo);
 		console.log(newTodo + " added to list");
}

function printList()
 {
   arr.forEach(function(todo,index)
    	{console.log(index+":"+todo);
    	}
     );
 }

 function deleteFromList()
   {var index=prompt("Enter index of task to be deleted");
     arr.splice(index,1);
     console.log("Todo Removed")
    }
