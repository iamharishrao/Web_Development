var p1=document.querySelector("#p1b");
var p2=document.querySelector("#p2b");
var res=document.querySelector("#resb");
var span1=document.querySelector("#span1");
var span2=document.querySelector("#span2");
var span3=document.querySelector("#span3");
var inp=document.querySelector("input");;
var p1Score=0;
var p2Score=0;
var winScore=5;
gameOver=false;
span3.textContent=winScore;

p1.addEventListener("click",function()
						{ if(!gameOver)
							{p1Score++;
								console.log(p1Score,winScore);
						 	 
						 	 if(p1Score===winScore)
						 	 {
						 	  span1.classList.add("green");
						 	  gameOver=true;


						 	 }
						 	 span1.textContent=p1Score;
						 	}

						  

						}

					);

p2.addEventListener("click",function()
						{if(!gameOver)
							{p2Score++;
						 	 if(p2Score===winScore)
						 	 {span2.classList.add("green");
						 	  gameOver=true;
								}
								span2.textContent=p2Score;
						 	}

						}
					);


res.addEventListener("click",function()
						{
								reset();
						}
						); 	

function reset()
{
						 p1Score=0;
						 p2Score=0;
						 span1.textContent=0;
						 span2.textContent=0;
						 span1.classList.remove("green");
						 span2.classList.remove("green"); 
						 gameOver=false;
}

inp.addEventListener("change",function()
				{span3.textContent=inp.value;
				 winScore=Number(inp.value);
				 reset();

});



