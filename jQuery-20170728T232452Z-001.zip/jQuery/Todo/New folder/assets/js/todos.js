$("ul").on("click","li",function()
{
   $(this).toggleClass("completed");
      
});


$("ul").on("click","span",function(event)
{   event.stopPropagation();
   		$(this).parent().fadeOut("slow",function()
   		{
   			$(this).remove();
   		});	  //just fadeOut().remove() will satrt the fade out but will not complete the fadeout before removing the element. Hence we fo in for the call back function within fadeout.
});

$("input[type='text']").keypress(function(event)
{
  if(event.which===13)
		{		//13 represeents hitting the Enter key  
  	var dataEntered=$(this).val();
  	$(this).val(" ");									//clears the text, acts as a setter
     $("ul").append("<li><span>X</span>" +" "+ dataEntered + "</li>"); 			//append adds a new li with the value in dataEntered
  }	
});




$(".fa-plus").click(function(){
	$("input[type='text']").fadeToggle();
});